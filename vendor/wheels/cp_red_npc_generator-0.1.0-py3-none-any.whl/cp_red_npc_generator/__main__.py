﻿#!/usr/bin/python
# -*- coding: utf-8 -*-

from .main import main

if __name__ == "__main__":
    raise SystemExit(main())
