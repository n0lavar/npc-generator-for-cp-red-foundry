#!/usr/bin/python
# -*- coding: utf-8 -*-

import functools
import logging
import math
from typing import List, Optional, Callable

import numpy as np

from .npc import Npc
from .npc_template import NpcTemplate
from .stats import Skill, StatType, SkillType
from .utils import clamp, load_data


def generate_stats_and_skills(npc: Npc, npc_template: NpcTemplate) -> Npc:
    def sort_and_modify(nums: List[int], modify_func: Callable[[int], Optional[int]]) -> List[int]:
        indexed_nums = list(enumerate(nums))
        sorted_indexed_nums = sorted(indexed_nums, key=lambda x: x[1], reverse=True)

        def apply_modify_func(values):
            changes_made = True
            while changes_made:
                changes_made = False
                for i in range(len(values)):
                    original_value = values[i][1]
                    new_value = modify_func(original_value)
                    if new_value is not None and new_value != original_value:
                        values[i] = (values[i][0], new_value)
                        changes_made = True
            return values

        modified_indexed_nums = apply_modify_func(sorted_indexed_nums)

        result = [0] * len(nums)
        for index, new_value in modified_indexed_nums:
            result[index] = new_value

        return result

    clamp_error: int = 0

    def fix_value(min_value: int, max_value: int, value: int) -> Optional[int]:
        nonlocal clamp_error
        if clamp_error > 0 and value < max_value:
            clamp_error -= 1
            return value + 1
        if clamp_error < 0 and value > min_value:
            clamp_error += 1
            return value - 1
        return None

    def distribute_points(weights: List[float],
                          num_points: float,
                          min_value: int,
                          max_value: int,
                          name: str) -> List[int]:
        nonlocal clamp_error

        logging.debug(f"\t{name}_{weights=}")
        logging.debug(f"\t{name}_{num_points=}")
        logging.debug(f"\t{name}_{min_value=}")
        logging.debug(f"\t{name}_{max_value=}")

        weights_sum = sum(weights)
        logging.debug(f"\t{name}_{weights_sum=}")

        mean_1: List[float] = [weight / weights_sum for weight in weights]
        logging.debug(f"\t{name}_{mean_1=}")

        mean_rank: List[float] = [mean * num_points for mean in mean_1]
        logging.debug(f"\t{name}_{mean_rank=}")

        mean_rounded: List[int] = [round(mean) for mean in mean_rank]
        logging.debug(f"\t{name}_{mean_rounded=}")

        mean_clamped: List[int] = list()
        clamp_error = 0
        for mean in mean_rounded:
            clamped = clamp(mean, min_value, max_value)
            clamp_error += (mean - clamped)
            mean_clamped.append(clamped)
        logging.debug(f"\t{name}_{mean_clamped=}")
        logging.debug(f"\t{name}_{clamp_error=}")

        mean_clamped_fixed = sort_and_modify(mean_clamped, functools.partial(fix_value, min_value, max_value))
        logging.debug(f"\t{name}_{mean_clamped_fixed=}")

        return mean_clamped_fixed

    logging.debug("\nGenerating stats...")
    stats_data = load_data("configs/stats.json")

    streetrat_stats_table: List[List[int]] = stats_data["streetrat_stats"][npc_template.role.name]
    streetrat_chosen_table: List[int] = streetrat_stats_table[np.random.choice(len(streetrat_stats_table))]
    stats_mean_clamped_distributed = distribute_points(
        streetrat_chosen_table,
        npc_template.rank.stats_budget.generate(),
        2,
        8,
        "stats")

    stats_sum: int = 0
    for i, stat in enumerate(stats_mean_clamped_distributed):
        npc.stats[StatType(i + 1)] = stat
        stats_sum += stat

    logging.debug(f"\t{stats_sum=}")
    logging.debug(f"\t{npc_template.rank.stats_budget.mean=}")
    logging.debug(f"\t{npc_template.rank.stats_budget.standard_deviation=}")

    logging.debug("\nGenerating skills...")
    all_skills_data = load_data("configs/skills.json")
    skill_specializations = load_data("configs/skill_specializations.json")
    forbidden_skills = set(npc_template.generation_rules.forbidden_skills or ())
    known_skill_names = set(all_skills_data) | set(skill_specializations)
    for skill_name in sorted(forbidden_skills - known_skill_names):
        logging.error("Forbidden skill does not exist: %s", skill_name)
    skills_data = {
        skill_name: skill_info
        for skill_name, skill_info in all_skills_data.items()
        if skill_name not in forbidden_skills
    }
    skill_specializations = {
        placeholder: [
            specialization
            for specialization in specializations
            if specialization not in forbidden_skills
        ]
        for placeholder, specializations in skill_specializations.items()
        if placeholder not in forbidden_skills
    }
    placeholder_skill_names = set(skill_specializations)
    specialization_names = {
        specialization
        for specializations in skill_specializations.values()
        for specialization in specializations
    }

    # add all skills with level 0
    for skill_name, skill_info in skills_data.items():
        if skill_name in placeholder_skill_names or skill_name in specialization_names:
            continue
        skill = Skill(skill_name, StatType[skill_info["link"]], SkillType(skill_info["type"]))
        npc.skills.setdefault(skill, 0)

    # increase values for role-specific skills
    role_skills = [
        (skill_name, skill_level)
        for skill_name, skill_level in npc_template.role.skills.items()
        if skill_name not in forbidden_skills
    ]
    for skill_name in npc_template.role.skills.keys() - known_skill_names:
        logging.error("Role uses a skill that does not exist: %s", skill_name)
    role_skills = [
        (skill_name, skill_level)
        for skill_name, skill_level in role_skills
        if skill_name in known_skill_names
    ]
    role_streetrat_skills_line: List[int] = [skill_level for _, skill_level in role_skills]
    role_streetrat_skills_distributed = (
        distribute_points(
            role_streetrat_skills_line,
            npc_template.rank.skills_budget.generate(),
            2,
            10,
            "skills")
        if role_streetrat_skills_line
        else []
    )

    skills_sum: int = 0
    for i, (skill_name, _) in enumerate(role_skills):
        if skill_name in skill_specializations:
            if not skill_specializations[skill_name]:
                logging.error("Skill %s has no supported specializations", skill_name)
                continue
            skill_name = str(np.random.choice(skill_specializations[skill_name]))
        skill_info = skills_data.get(skill_name)
        if skill_info is None:
            logging.error("Role uses a forbidden or nonexistent skill: %s", skill_name)
            continue
        skill = Skill(skill_name, StatType[skill_info["link"]], SkillType(skill_info["type"]))
        npc.skills[skill] = npc.skills.get(skill, 0) + role_streetrat_skills_distributed[i]
        skills_sum += role_streetrat_skills_distributed[i]

    # possibly replace Brawling with a specific Martial Arts form
    if (npc_template.generation_rules.allow_martial_arts
            and np.random.uniform(0, 1) < npc_template.role.martial_arts_probability):
        brawling_skill = next((s for s in npc.skills.keys() if s.name == "Brawling"), None)
        if brawling_skill is None:
            logging.error("Martial arts generation requires the nonexistent skill Brawling")
            return npc
        brawling_skill_value = npc.skills[brawling_skill]

        martial_arts_forms = skill_specializations.get("MartialArts", [])
        if not martial_arts_forms:
            logging.error("Martial arts generation has no supported skills")
            return npc
        martial_arts_name = str(np.random.choice(martial_arts_forms))
        martial_arts_info = skills_data.get(martial_arts_name)
        if martial_arts_info is None:
            logging.error("Martial arts generation selected a nonexistent skill: %s", martial_arts_name)
            return npc
        martial_arts_skill = Skill(
            martial_arts_name,
            StatType[martial_arts_info["link"]],
            SkillType(martial_arts_info["type"]))
        new_martial_arts_skill_value = math.ceil(brawling_skill_value / 2)

        if new_martial_arts_skill_value > 0:
            npc.skills[brawling_skill] = 0
            npc.skills[martial_arts_skill] = new_martial_arts_skill_value

    logging.debug(f"\t{skills_sum=}")
    logging.debug(f"\t{npc_template.rank.skills_budget.mean=}")
    logging.debug(f"\t{npc_template.rank.skills_budget.standard_deviation=}")

    return npc
