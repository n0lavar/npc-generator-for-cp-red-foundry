#!/usr/bin/python
# -*- coding: utf-8 -*-

import argparse
import builtins
import json
import math
import time
import types
import numpy as np
from importlib.resources import files
from bisect import bisect_right
from collections.abc import Callable, Iterable, Iterator, MutableSet
from typing import Generic, List, TypeVar
from faker import Faker

RANDOM_GENERATING_NUM_ATTEMPTS: int = 200
T = TypeVar("T")


class SortedSet(MutableSet[T], Generic[T]):
    def __init__(self, iterable: Iterable[T] = (), key: Callable[[T], object] = lambda value: value):
        self._items = []
        self._key = key
        for item in iterable:
            self.add(item)

    def __contains__(self, item: T) -> bool:
        return item in self._items

    def __iter__(self) -> Iterator[T]:
        return iter(self._items)

    def __len__(self) -> int:
        return len(self._items)

    def add(self, item: T) -> None:
        if item in self:
            return
        keys = [self._key(existing) for existing in self._items]
        self._items.insert(bisect_right(keys, self._key(item)), item)

    def discard(self, item: T) -> None:
        try:
            self._items.remove(item)
        except ValueError:
            pass


def left_align(obj, offset: int = 0, char: str = "\t") -> str:
    return char * offset + obj


def choose_exponential_random_element(elements):
    def exponential_distribution_probability_density_function(x: float, lambda_: float) -> float:
        if x >= 0:
            return lambda_ * np.exp(-lambda_ * x)
        else:
            return 0

    weights: List[float] = [exponential_distribution_probability_density_function(x * 20 / len(elements), 0.2)
                            for x in range(len(elements))]
    probabilities: List[float] = [x / sum(weights) for x in weights]
    index: int = np.random.choice(len(elements), p=probabilities)
    return elements[index]


def package_resource(path: str):
    """Return a resource from the package canonical configs directory."""
    relative_path = path.replace("\\", "/").removeprefix("configs/")
    resource = files("cp_red_npc_generator") / "configs"
    for part in relative_path.split("/"):
        resource = resource / part
    return resource


def load_data(json_path: str):
    return json.loads(package_resource(json_path).read_text(encoding="utf-8"))


def clamp(n, min_value, max_value):
    if n < min_value:
        return min_value
    elif n > max_value:
        return max_value
    else:
        return n


def get_allowed_items(items: List[str], normalized_index: float) -> List[str]:
    """

    :param items: all items list where the elements are sorted from the coolest one to the worst
    :param normalized_index: a number from 0 to 1 representing the index of the coolest allowed item
    :return: `items` but without the coolest items depending on normalized_index
    """
    sequence_len: int = len(items)
    index: int = math.floor((sequence_len - 1) * normalized_index)
    return items[index:sequence_len]


def args_to_str(args) -> str:
    result: str = ""
    for key, value in args.items():
        match type(value):
            case builtins.bool:
                result += f"--{key}" if value else f"--no-{key}"
            case types.NoneType:
                result += f"--no-{key}"
            case _:
                result += f"--{key}={value}"

        result += " "

    return result


def setup_random(args: argparse.Namespace) -> int:
    if args.seed != 0:
        seed: int = args.seed
    else:
        seed: int = int(time.time_ns() % 1e9)

    np.random.seed(seed)
    Faker.seed(seed)

    return seed
