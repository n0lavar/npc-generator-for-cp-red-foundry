# !/usr/bin/python
# -*- coding: utf-8 -*-

import logging
import math
from dataclasses import dataclass
from typing import Dict, Iterable, List, Mapping, NotRequired, Optional, Tuple, TypedDict, cast

import numpy as np

from .item import Item, ItemType
from .npc import Npc
from .npc_template import NpcTemplate
from .utils import choose_exponential_random_element, load_data

AUTOFIRE_AMMO_PER_ATTACK: int = 10
AUTOFIRE_ATTACKS_COUNT: int = 6
NON_AUTOFIRE_ATTACKS_COUNT: int = 12


class AmmoModificationData(TypedDict):
    types: List[str]
    price: int
    name: NotRequired[str]


AmmoConfig = Mapping[str, AmmoModificationData]
AffordableModification = Tuple[str, int]
PurchaseCandidate = Tuple[str, int, List[AffordableModification]]
AmmoPurchase = Tuple[str, str, int, int]


@dataclass(frozen=True)
class AmmoRequirement:
    magazine_size: int
    total: int


def _round_up_to_magazine(amount: int, magazine_size: int) -> int:
    return math.ceil(amount / magazine_size) * magazine_size


def _has_trained_skill(npc: Npc, skill_name: str) -> bool:
    return any(skill.name == skill_name and level > 0 for skill, level in npc.skills.items())


def _weapon_ammo_requirement(weapon: Item, can_use_autofire: bool) -> AmmoRequirement:
    magazine_size: int = max(1, weapon.magazine or 1)
    weapon_tags: List[str] = weapon.get_all_tags()
    if "LimitedAmmoWeapon" in weapon_tags:
        total: int = 2
    elif can_use_autofire and "AutofireWeapon" in weapon_tags:
        total = _round_up_to_magazine(
            AUTOFIRE_AMMO_PER_ATTACK * AUTOFIRE_ATTACKS_COUNT,
            magazine_size,
        )
    else:
        total = _round_up_to_magazine(
            (weapon.rate_of_fire or 1) * NON_AUTOFIRE_ATTACKS_COUNT,
            magazine_size,
        )
    return AmmoRequirement(magazine_size, total)


def _distribute_ammo_requirement(
        weapon: Item,
        requirement: AmmoRequirement,
) -> Dict[str, AmmoRequirement]:
    ammo_types_count: int = len(weapon.ammo_types)
    if ammo_types_count == 0:
        return {}

    divided_amount: int = math.ceil(requirement.total / ammo_types_count)
    amount_per_type: int = _round_up_to_magazine(
        divided_amount,
        requirement.magazine_size,
    )
    return {
        ammo_type: AmmoRequirement(
            magazine_size=requirement.magazine_size,
            total=amount_per_type,
        )
        for ammo_type in weapon.ammo_types
    }


def _collect_ammo_requirements(
        npc: Npc,
        include_standalone_grenade: bool = False,
) -> Dict[str, AmmoRequirement]:
    can_use_autofire = _has_trained_skill(npc, "Autofire")
    requirements: Dict[str, AmmoRequirement] = {}
    if include_standalone_grenade:
        requirements["Grenade"] = AmmoRequirement(magazine_size=1, total=1)
    for weapon in npc.weapons:
        weapon_requirement: AmmoRequirement = _weapon_ammo_requirement(
            weapon,
            can_use_autofire,
        )
        distributed_requirements: Dict[str, AmmoRequirement] = _distribute_ammo_requirement(
            weapon,
            weapon_requirement,
        )
        for ammo_type, requirement in distributed_requirements.items():
            current: Optional[AmmoRequirement] = requirements.get(ammo_type)
            if current is None or (requirement.total, requirement.magazine_size) > (
                    current.total, current.magazine_size):
                requirements[ammo_type] = requirement
    return requirements


def _ammo_price(ammo_type: str, modification_data: AmmoModificationData) -> int:
    price: int = modification_data["price"]
    return price * 10 if ammo_type in ("Grenade", "Rocket") else price


def _make_ammo_item(
        ammo_type: str,
        modification: str,
        modification_data: AmmoModificationData,
) -> Item:
    price: int = _ammo_price(ammo_type, modification_data)
    return Item(
        modification_data.get("name", f"{ammo_type} ({modification})"),
        ItemType.AMMO,
        price,
    )


def _add_ammo(npc: Npc, item: Item, amount: int) -> None:
    npc.inventory[item] = npc.inventory.get(item, 0) + amount
    logging.debug("\tAdded %s of %s", amount, item)


def _eligible_non_basic_modifications(
        ammo_type: str,
        preferred_modifications: Iterable[str],
        ammo_data: AmmoConfig,
) -> List[str]:
    return [
        modification
        for modification in preferred_modifications
        if modification != "Basic"
           and modification in ammo_data
           and ammo_type in ammo_data[modification]["types"]
    ]


def _choose_non_basic_purchase(
        requirements: Mapping[str, AmmoRequirement],
        amounts_added: Mapping[str, int],
        preferred_modifications: Iterable[str],
        ammo_data: AmmoConfig,
        budget: int,
        npc: Npc,
) -> Optional[AmmoPurchase]:
    candidates: List[PurchaseCandidate] = []
    for ammo_type, requirement in requirements.items():
        amount: int = requirement.magazine_size
        if amounts_added.get(ammo_type, 0) + amount > requirement.total:
            continue
        modifications: List[str] = _eligible_non_basic_modifications(
            ammo_type, preferred_modifications, ammo_data)
        affordable: List[AffordableModification] = []
        for modification in modifications:
            item: Item = _make_ammo_item(ammo_type, modification, ammo_data[modification])
            cost: int = item.price * amount
            if cost <= budget:
                affordable.append((modification, cost))
        if affordable:
            candidates.append((ammo_type, amount, affordable))

    if not candidates:
        return None
    candidate_index: int = int(np.random.choice(len(candidates)))
    ammo_type, amount, affordable = candidates[candidate_index]
    affordable_by_name: Dict[str, int] = dict(affordable)
    modification: str = cast(
        str,
        choose_exponential_random_element(list(affordable_by_name)),
    )
    return ammo_type, modification, amount, affordable_by_name[modification]


def _add_non_basic_ammo(
        npc: Npc,
        requirements: Mapping[str, AmmoRequirement],
        preferred_modifications: Iterable[str],
        ammo_data: AmmoConfig,
        budget: int,
) -> Dict[str, int]:
    amounts_added: Dict[str, int] = {ammo_type: 0 for ammo_type in requirements}
    while purchase := _choose_non_basic_purchase(
            requirements, amounts_added, preferred_modifications, ammo_data, budget, npc):
        ammo_type, modification, amount, cost = purchase
        _add_ammo(npc, _make_ammo_item(ammo_type, modification, ammo_data[modification]), amount)
        amounts_added[ammo_type] += amount
        budget -= cost
    return amounts_added


def _basic_modification(ammo_type: str, ammo_data: AmmoConfig) -> str:
    basic_data: Optional[AmmoModificationData] = ammo_data.get("Basic")
    if basic_data is not None and ammo_type in basic_data["types"]:
        return "Basic"
    return next(
        modification
        for modification, data in ammo_data.items()
        if ammo_type in data["types"]
    )


def generate_ammo(npc: Npc, npc_template: NpcTemplate) -> Npc:
    logging.debug("\nGenerating ammo...")
    ammo_data: AmmoConfig = cast(
        AmmoConfig,
        load_data("configs/items/ammo.json"),
    )
    requirements: Dict[str, AmmoRequirement] = _collect_ammo_requirements(
        npc,
        npc_template.generation_rules.allow_grenades,
    )
    logging.debug("\t%s", requirements)

    amounts_added: Dict[str, int] = {ammo_type: 0 for ammo_type in requirements}
    if npc_template.generation_rules.allow_non_basic_ammo:
        budget: int = round(npc_template.rank.items_budget[ItemType.AMMO].generate())
        amounts_added = _add_non_basic_ammo(
            npc,
            requirements,
            npc_template.role.preferred_ammo,
            ammo_data,
            budget,
        )

    for ammo_type, requirement in requirements.items():
        amount: int = requirement.total - amounts_added[ammo_type]
        if amount <= 0:
            continue
        modification: str = _basic_modification(ammo_type, ammo_data)
        _add_ammo(
            npc,
            _make_ammo_item(ammo_type, modification, ammo_data[modification]),
            amount,
        )
    return npc
