# !/usr/bin/python
# -*- coding: utf-8 -*-

import json
import logging
import sys
from collections.abc import Set
from dataclasses import fields, is_dataclass
from enum import Enum
from functools import cache
from typing import Any, Optional

import numpy as np
from babel import Locale
from faker import Faker
from faker.config import AVAILABLE_LOCALES
from unidecode import unidecode

from .generate_lifepath import generate_lifepath
from .normal_distribution import NormalDistribution
from .npc import Npc
from .npc_template import NpcTemplate
from .utils import load_data, package_resource


@cache
def _populations() -> dict[str, int]:
    return load_data("configs/nationality_weights.json")["populations"]


@cache
def _nationality_locales() -> dict[str, tuple[str, ...]]:
    populations = _populations()
    nationality_locales: dict[str, tuple[str, ...]] = {}
    for locale in sorted(AVAILABLE_LOCALES):
        territory = locale.rsplit("_", 1)[-1]
        if territory not in populations:
            continue
        nationality = Locale("en").territories[territory]
        nationality_locales[nationality] = (
            *nationality_locales.get(nationality, ()), locale
        )
    return nationality_locales


@cache
def _nationality_distribution() -> tuple[tuple[str, ...], np.ndarray]:
    populations = _populations()
    nationality_locales = _nationality_locales()
    nationalities = sorted(nationality_locales)
    weights = np.array([
        populations[nationality_locales[nationality][0].rsplit("_", 1)[-1]]
        for nationality in nationalities
    ], dtype=float)
    probability_order = np.argsort(-weights, kind="stable")
    ordered_nationalities = tuple(
        nationalities[index] for index in probability_order
    )
    probabilities = weights[probability_order]
    probabilities /= probabilities.sum()
    return ordered_nationalities, probabilities


def get_nationalities() -> tuple[str, ...]:
    return _nationality_distribution()[0]


def choose_nationality() -> str:
    nationalities, probabilities = _nationality_distribution()
    return str(np.random.choice(nationalities, p=probabilities))


def choose_locale(nationality: str) -> str:
    """Choose a Faker locale for a human-readable nationality."""
    locales = _nationality_locales()[nationality]
    return locales[int(np.random.randint(len(locales)))]


def _transliterate_name(value: str) -> str:
    transliterated = unidecode(value)
    if value.lower() == value.upper():
        return transliterated.title()
    return transliterated


def _generate_name_surname(npc: Npc, npc_template: NpcTemplate) -> Npc:
    faker = Faker(choose_locale(npc_template.nationality))
    if npc.sex:
        npc.name = _transliterate_name(faker.first_name_male())
        npc.surname = _transliterate_name(faker.last_name_male())
    else:
        npc.name = _transliterate_name(faker.first_name_female())
        npc.surname = _transliterate_name(faker.last_name_female())

    return npc


def _json_value(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Enum):
        return value.name
    if is_dataclass(value):
        return {
            item.name: _json_value(getattr(value, item.name))
            for item in fields(value)
            if item.name not in {"id", "creation_time"}
        }
    if isinstance(value, dict):
        return {str(_json_value(key)): _json_value(item) for key, item in value.items()}
    if isinstance(value, Set):
        return [_json_value(item) for item in value]
    if isinstance(value, (list, tuple)):
        return [_json_value(item) for item in value]
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return str(value)


async def _request_ai_description(url: str, headers: dict[str, str], body: str) -> dict:
    if sys.platform == "emscripten":
        from pyodide.http import pyfetch

        response = await pyfetch(url, method="POST", headers=headers, body=body)
        if not response.ok:
            raise RuntimeError(f"HTTP {response.status}: {response.status_text}")
        return await response.json()
    else:
        from urllib import request

        http_request = request.Request(
            url,
            data=body.encode("utf-8"),
            headers=headers,
            method="POST")
        with request.urlopen(http_request, timeout=60) as response:
            return json.loads(response.read().decode("utf-8"))


@cache
def _description_prompt() -> str:
    return package_resource("description_prompt.md").read_text(
        encoding="utf-8"
    ).strip()


async def _generate_ai_description(npc: Npc,
                                   npc_template: NpcTemplate,
                                   model_id: Optional[str],
                                   model_api_key: Optional[str],
                                   model_base_url: Optional[str],
                                   model_language: str,
                                   seed: int) -> Npc:
    if not all((model_id, model_api_key, model_base_url)):
        return npc

    npc_data = _json_value(npc)
    npc_data.pop("description", None)
    context = {"npc": npc_data, "npc_template": _json_value(npc_template)}
    payload = {
        "model": model_id,
        "messages": [
            {
                "role": "system",
                "content": (
                    f"{_description_prompt()} "
                    f"Write the description in {model_language}."
                )
            },
            {
                "role": "user",
                "content": json.dumps(context, ensure_ascii=False)
            },
        ],
        "temperature": 0.5,
        "seed": seed,
    }
    try:
        result = await _request_ai_description(
            model_base_url.rstrip("/") + "/chat/completions",
            {"Authorization": f"Bearer {model_api_key}", "Content-Type": "application/json"},
            json.dumps(payload, ensure_ascii=False),
        )
        description = result["choices"][0]["message"]["content"].strip()
        if description:
            npc.description = description
    except Exception as exc:
        logging.warning("AI description was not generated: %s", exc)
    return npc


async def generate_description(npc: Npc,
                               npc_template: NpcTemplate,
                               model_id: Optional[str],
                               model_api_key: Optional[str],
                               model_base_url: Optional[str],
                               model_language: str,
                               seed: int,
                               allow_description: bool,
                               allow_lifepath: bool) -> Npc:
    npc.sex = np.random.choice([True, False])
    npc.nationality = npc_template.nationality
    npc.age = round(NormalDistribution(20 + 5 * npc_template.rank.rank_number, 2).generate())
    npc = _generate_name_surname(npc, npc_template)
    if allow_lifepath:
        npc.lifepath = generate_lifepath(npc.nationality)
    if allow_description:
        npc = await _generate_ai_description(npc, npc_template, model_id, model_api_key,
                                             model_base_url, model_language, seed)
    return npc
