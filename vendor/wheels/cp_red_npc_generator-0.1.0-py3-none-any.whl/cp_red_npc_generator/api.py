# !/usr/bin/python
# -*- coding: utf-8 -*-

"""Public synchronous generation API."""

import time

import dataclass_wizard
import numpy as np
from faker import Faker

from .args import GenerationRules, get_generation_options
from .generate_description import choose_nationality
from .main import create_npc
from .npc import Npc
from .npc_template import NpcTemplate, Rank, Role


async def generate_npc(rules: GenerationRules) -> Npc:
    """Generate an NPC without reading command-line arguments or printing output."""
    if not isinstance(rules, GenerationRules):
        raise TypeError("rules must be a GenerationRules instance")

    options = {option.name: option for option in get_generation_options().fields}
    ranks = Rank.load()
    if rules.rank.isnumeric():
        rank_number = int(rules.rank)
        if rank_number < 0 or rank_number >= len(ranks):
            raise ValueError(f"rank number must be between 0 and {len(ranks) - 1}")
    else:
        if rules.rank not in options["rank"].choices:
            raise ValueError(f"unknown rank: {rules.rank!r}")
        rank_number = options["rank"].choices.index(rules.rank)

    roles = Role.load()
    if rules.role not in options["role"].choices:
        raise ValueError(f"unknown role: {rules.role!r}")
    if rules.nationality is not None and rules.nationality not in options["nationality"].choices:
        raise ValueError(f"unknown nationality: {rules.nationality!r}")

    rules.seed = rules.seed or int(time.time_ns() % 1e9)
    np.random.seed(rules.seed)
    Faker.seed(rules.seed)
    rules.nationality = rules.nationality or choose_nationality()

    rank = dataclass_wizard.fromdict(Rank, ranks[rank_number])
    rank.rank_number = rank_number
    role = dataclass_wizard.fromdict(Role, roles[options["role"].choices.index(rules.role)])
    return await create_npc(
        NpcTemplate(rank, role, rules, rules.nationality),
        rules.model_id,
        rules.model_api_key,
        rules.model_base_url,
        rules.model_language,
        rules.seed,
        rules.allow_description,
        rules.allow_lifepath,
    )
