# !/usr/bin/python
# -*- coding: utf-8 -*-

import argparse
import dataclasses
import json
import logging
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


class _StoreTupleAction(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        setattr(namespace, self.dest, tuple(values))


def _generation_option(
        *,
        default,
        group: str,
        help: str,
        value_type=None,
        choices: Optional[str] = None,
        boolean: bool = False,
        multiple: bool = False):
    """Define one generation option for both the Python API and argparse."""
    return field(default=default, metadata={
        "group": group,
        "help": help,
        "value_type": value_type,
        "choices": choices,
        "boolean": boolean,
        "multiple": multiple,
    })


@dataclass
class GenerationRules:
    rank: str = _generation_option(
        default="captain",
        group="NPC Customization",
        help="A measure of the development of a given NPC, where private is an unskilled and unknown newcomer, "
             "and general is a world-class character. "
             "Rank determines how advanced an NPC's skills are and how cool his equipment is.",
        value_type=str,
        choices="ranks")
    role: str = _generation_option(
        default="solo",
        group="NPC Customization",
        help="An occupation the NPC is known by on The Street. "
             "`civilian` means that this is just a regular human. "
             "The role can determine the equipment and the direction of the NPC's skills. The default value is `solo`.",
        value_type=str,
        choices="roles")
    nationality: Optional[str] = _generation_option(
        default=None,
        group="NPC Customization",
        help="Nationality used to generate the NPC name, e.g. Russia or United States. "
             "If omitted, a random nationality is used.",
        value_type=str,
        choices="nationalities")
    allow_non_basic_ammo: bool = _generation_option(
        default=True,
        group="NPC Customization",
        help="If specified, allow non-basic ammo, such as armor piercing and expansive.",
        boolean=True)
    allow_grenades: bool = _generation_option(
        default=True,
        group="NPC Customization",
        help="If specified, allow grenades.",
        boolean=True)
    allow_armor: bool = _generation_option(
        default=True,
        group="NPC Customization",
        help="If specified, allow armor items (cyberware armor will still be there).",
        boolean=True)
    allow_cyberware: bool = _generation_option(
        default=True,
        group="NPC Customization",
        help="If specified, allow cyberware.",
        boolean=True)
    allow_borgware: bool = _generation_option(
        default=False,
        group="NPC Customization",
        help="If specified, allow borgware. Usually you don't want regular mooks to use that cool stuff.",
        boolean=True)
    allow_drugs: bool = _generation_option(
        default=True,
        group="NPC Customization",
        help="If specified, allow adding drugs. Drugs may be added or not depending on airhypo generation.",
        boolean=True)
    allow_equipment: bool = _generation_option(
        default=True,
        group="NPC Customization",
        help="If specified, allow equipment, such as flashlight and airhypo (cyberware equipment will still be there).",
        boolean=True)
    allow_money: bool = _generation_option(
        default=True,
        group="NPC Customization",
        help="If specified, allow money.",
        boolean=True)
    allow_junk: bool = _generation_option(
        default=True,
        group="NPC Customization",
        help="If specified, allow useless junk for flavor.",
        boolean=True)
    allow_melee_weapon: bool = _generation_option(
        default=True,
        group="NPC Customization",
        help="If specified, allow melee weapons (brawling, martial arts and cyberware weapons will still be there).",
        boolean=True)
    allow_ranged_weapon: bool = _generation_option(
        default=True,
        group="NPC Customization",
        help="If specified, allow ranged weapons (cyberware weapons will still be there).",
        boolean=True)
    allow_martial_arts: bool = _generation_option(
        default=True,
        group="NPC Customization",
        help="If specified, allow martial arts (brawling will still be there).",
        boolean=True)
    allow_description: bool = _generation_option(
        default=False,
        group="NPC Customization",
        help="If specified, allow AI generation of the NPC description.",
        boolean=True)
    allow_lifepath: bool = _generation_option(
        default=True,
        group="NPC Customization",
        help="If specified, randomly generate the NPC Lifepath from the core rulebook tables.",
        boolean=True)
    seed: int = _generation_option(
        default=0,
        group="Generation settings",
        help='A number for the random engine. '
             'The same seed always gives the same result when the other arguments are unchanged. '
             'Zero means "use Unix epoch".',
        value_type=int)
    model_id: Optional[str] = _generation_option(
        default="qwen/qwen3.6-35b-a3b",
        group="Generation settings",
        help="Model identifier used to generate the NPC description.",
        value_type=str)
    model_api_key: Optional[str] = _generation_option(
        default="lm-studio",
        group="Generation settings",
        help="API key for the OpenAI-compatible model server.",
        value_type=str)
    model_base_url: Optional[str] = _generation_option(
        default="http://localhost:1234/v1",
        group="Generation settings",
        help="Base URL of the OpenAI-compatible model server.",
        value_type=str)
    model_language: str = _generation_option(
        default="English",
        group="Generation settings",
        help="Language in which the model generates the NPC description.",
        value_type=str)
    flat: bool = _generation_option(
        default=None, group="Appearance",
        boolean=True,
        help="If specified, don't use columns. Easier for editing and copy-pasting, but takes much more space.")
    json_output: bool = _generation_option(
        default=False,
        group="Appearance",
        boolean=True,
        help="If specified, output results in JSON format.")
    log_level: str = _generation_option(
        default=logging.getLevelName(logging.INFO),
        group="Appearance",
        value_type=str,
        choices="log_levels",
        help="Logging level.")
    forbidden_skills: tuple[str, ...] = _generation_option(
        default=(),
        group="Compatibility",
        help="A skill that must not be generated because the target module does not support it. "
             "Accepts one or more values.",
        value_type=str,
        multiple=True)


@dataclass(frozen=True)
class GenerationOption:
    name: str
    help: str
    type: Optional[type]
    choices: Optional[tuple[Any, ...]]
    default: Any
    group: str
    boolean: bool
    multiple: bool


@dataclass(frozen=True)
class GenerationOptions:
    fields: tuple[GenerationOption, ...]


def get_generation_choices(ranks=None, roles=None) -> dict[str, tuple[str, ...]]:
    from .generate_description import get_nationalities
    from .npc_template import Rank, Role
    if ranks is None:
        ranks = Rank.load()
    if roles is None:
        roles = Role.load()
    return {
        "ranks": tuple(rank["name"] for rank in ranks),
        "roles": tuple(role["name"] for role in roles),
        "nationalities": get_nationalities(),
        "log_levels": tuple(logging.getLevelNamesMapping()),
    }


def _find_settings_path() -> Path:
    candidates = [Path.cwd() / "settings.json"]
    if getattr(sys, "frozen", False):
        candidates.append(Path(sys.executable).resolve().parent / "settings.json")
    else:
        candidates.append(Path(__file__).resolve().parents[2] / "settings.json")
    return next((path for path in candidates if path.is_file()), candidates[0])


def _load_settings() -> dict:
    settings_path = _find_settings_path()
    if not settings_path.is_file():
        return {}
    with settings_path.open(encoding="utf-8") as settings_file:
        settings = json.load(settings_file)
    if not isinstance(settings, dict):
        raise ValueError(f"{settings_path} must contain a JSON object")
    return {key.replace("-", "_"): value for key, value in settings.items()}


def get_generation_options() -> GenerationOptions:
    choices = get_generation_choices()
    options = []
    for rule_field in dataclasses.fields(GenerationRules):
        metadata = rule_field.metadata
        choice_name = metadata["choices"]
        option_choices = choices[choice_name] if choice_name else None
        if choice_name == "ranks":
            option_choices += tuple(str(index) for index in range(len(choices["ranks"])))
        options.append(GenerationOption(
            name=rule_field.name,
            help=metadata["help"],
            type=bool if metadata["boolean"] else metadata["value_type"],
            choices=option_choices,
            default=rule_field.default,
            group=metadata["group"],
            boolean=metadata["boolean"],
            multiple=metadata["multiple"],
        ))
    return GenerationOptions(tuple(options))


def create_and_parse_args(argv=None, load_settings=True) -> GenerationRules:
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    groups = {}
    options = get_generation_options()
    for option in options.fields:
        group = groups.setdefault(option.group, parser.add_argument_group(option.group))
        kwargs = {"help": option.help, "default": option.default}
        if option.boolean:
            kwargs["action"] = argparse.BooleanOptionalAction
        elif option.multiple:
            kwargs["action"] = _StoreTupleAction
            kwargs["nargs"] = "+"
        else:
            kwargs["type"] = option.type
        if option.choices:
            kwargs["choices"] = option.choices
        group.add_argument("--" + option.name.replace("_", "-"), **kwargs)

    if load_settings:
        settings = _load_settings()
        known_arguments = {option.name for option in options.fields}
        unknown_settings = settings.keys() - known_arguments
        if unknown_settings:
            parser.error(f"unknown settings: {', '.join(sorted(unknown_settings))}")
        parser.set_defaults(**settings)
    return GenerationRules(**vars(parser.parse_args(argv)))
