#!/usr/bin/python
# -*- coding: utf-8 -*-

import asyncio
import json
import logging
import sys

import numpy as np

from .generate_trauma_team_status import generate_trauma_team_status
from .generate_description import generate_description
from .generate_ammo import generate_ammo
from .generate_armor import generate_armor
from .generate_cyberware import generate_cyberware
from .generate_drugs import generate_drugs
from .generate_equipment import generate_equipment
from .generate_junk import generate_junk
from .generate_stats import generate_stats_and_skills
from .generate_weapon import generate_weapon
from .npc import Npc
from .npc_template import NpcTemplate
from .logger import setup_logging
from .args import create_and_parse_args
from .utils import args_to_str


async def create_npc(npc_template: NpcTemplate,
               model_id: str,
               model_api_key: str,
               model_base_url: str,
               model_language: str,
               seed: int) -> Npc:
    logging.debug(f"Input:")
    logging.debug(f"\trank: {npc_template.rank.name}")
    logging.debug(f"\trole: {npc_template.role.name}")
    logging.debug(f"\tgeneration_rules: {npc_template.generation_rules}")

    npc = Npc()
    npc = generate_stats_and_skills(npc, npc_template)
    npc = generate_cyberware(npc, npc_template)
    npc = generate_weapon(npc, npc_template)
    npc = generate_ammo(npc, npc_template)
    npc = generate_equipment(npc, npc_template)
    npc = generate_armor(npc, npc_template)
    npc = generate_drugs(npc, npc_template)
    npc = generate_junk(npc, npc_template)
    npc = generate_trauma_team_status(npc, npc_template)
    npc = await generate_description(npc, npc_template, model_id, model_api_key,
                               model_base_url, model_language, seed)
    return npc


def main() -> int:
    from .api import generate_npc

    args = create_and_parse_args()
    setup_logging(args)
    npc = asyncio.run(generate_npc(args))

    if not args.foundry_json:
        logging.info(
            "<=================================================================================================>")
        args_dict = dict(vars(args))
        for key, value in args_dict.copy().items():
            args_dict[key.replace("_", "-")] = args_dict.pop(key)
        logging.info(f"\n{args_to_str(args_dict)}")
        logging.info(npc.to_string(args.flat))
    else:
        print(json.dumps(npc.to_dict_foundry_vvt(), ensure_ascii=False, indent=2,
                         default=np.generic.item))

    return 0


if __name__ == "__main__":
    sys.exit(main())
