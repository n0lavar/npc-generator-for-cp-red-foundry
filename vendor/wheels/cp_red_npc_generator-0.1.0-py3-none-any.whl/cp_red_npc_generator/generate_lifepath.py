#!/usr/bin/python
# -*- coding: utf-8 -*-
 
from typing import Any, Optional

import numpy as np
from babel import Locale
from babel.core import UnknownLocaleError

from .utils import load_data

_LIFEPATH: dict[str, Any] = load_data("configs/lifepath.json")


def _choose(name: str) -> Any:
    values = _LIFEPATH[name]
    return values[int(np.random.randint(len(values)))]


def _count() -> int:
    return max(0, int(np.random.randint(1, 11)) - 7)


def _origin_and_language(
        nationality: Optional[str],
) -> tuple[str, Optional[str]]:
    if not nationality:
        origin = _choose("cultural_origins")
        return origin["region"], _choose_from(origin["languages"])
    try:
        locale = Locale.parse(nationality)
        origin = locale.get_territory_name("en")
        language = locale.get_language_name("en")
        if not origin or not language:
            raise UnknownLocaleError(nationality)
        return origin, language
    except (UnknownLocaleError, ValueError):
        return nationality, None


def generate_lifepath(nationality: Optional[str] = None) -> dict[str, Any]:
    origin, language = _origin_and_language(nationality)
    friends = [_choose("friend_relationship") for _ in range(_count())]
    enemies = [
        {
            "enemy": _choose("enemy"),
            "cause": _choose("enemy_cause"),
            "wronged_party": _choose_from(("You", "They")),
            "resources": _choose("enemy_resources"),
            "reaction": _choose("sweet_revenge"),
        }
        for _ in range(_count())
    ]
    tragic_love_affairs = [
        _choose("tragic_love_affair") for _ in range(_count())
    ]
    lifepath: dict[str, Any] = {"cultural_origin": origin}
    if language is not None:
        lifepath["language"] = language
    lifepath.update({
        "personality": _choose("personality"),
        "clothing_style": _choose("clothing_style"),
        "hairstyle": _choose("hairstyle"),
        "affectation": _choose("affectation"),
        "value_most": _choose("value_most"),
        "feel_about_people": _choose("feel_about_people"),
        "valued_person": _choose("valued_person"),
        "valued_possession": _choose("valued_possession"),
        "family_background": _choose("family_background"),
        "childhood_environment": _choose("childhood_environment"),
        "family_crisis": _choose("family_crisis"),
        "friends": friends,
        "enemies": enemies,
        "tragic_love_affairs": tragic_love_affairs,
        "life_goal": _choose("life_goal"),
    })
    return lifepath


def _choose_from(values) -> Any:
    return values[int(np.random.randint(len(values)))]
