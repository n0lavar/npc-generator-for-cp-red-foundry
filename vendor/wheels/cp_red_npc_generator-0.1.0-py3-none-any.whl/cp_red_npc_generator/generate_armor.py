#!/usr/bin/python
# -*- coding: utf-8 -*-

import logging
from dataclasses import replace

import dataclass_wizard
from typing import List, Optional, Tuple, Dict

from .item import Item, ItemType, Modifier
from .npc import Npc
from .npc_template import NpcTemplate
from .utils import load_data


def pick_armor(budget: int, preferred_armor_class: int, all_armor: List[Item]) -> Tuple[Optional[Item], int]:
    for armor in all_armor:
        if armor.price > budget:
            logging.debug(f"\tFailed to pick, not enough money (required: {armor.price}, available: {budget})")
            continue

        if armor.armor_class > preferred_armor_class:
            logging.debug(f"\tFailed to pick, the armor class is too high: {armor.armor_class}")
            continue

        return armor, armor.price

    return None, 0


def apply_armor_penalties_once(npc: Npc) -> None:
    """Keep only the greatest armor penalty for each stat and apply it once."""
    greatest_penalties: Dict[str, int] = {}
    penalty_carrier: Optional[Item] = None

    for armor in list(npc.armor):
        for modifier in armor.modifiers:
            if modifier.simple < greatest_penalties.get(modifier.name, 0):
                greatest_penalties[modifier.name] = modifier.simple
                penalty_carrier = armor

        npc.armor.discard(armor)
        npc.armor.add(replace(armor, modifiers=[modifier for modifier in armor.modifiers if modifier.simple > 0]))

    if penalty_carrier:
        npc.armor.discard(penalty_carrier)
        npc.armor.add(replace(
            penalty_carrier,
            modifiers=[modifier for modifier in penalty_carrier.modifiers if modifier.simple > 0]
                      + [Modifier(name, value) for name, value in greatest_penalties.items()],
        ))


def generate_armor(npc: Npc, npc_template: NpcTemplate) -> Npc:
    logging.debug("\nGenerating armor...")

    # check if we already have a cyberware that can act like an armor
    armor_cyberware: Optional[Item] = None
    for cyberware in npc.cyberware:
        if "Armor" in cyberware.item.tags:
            armor_cyberware = cyberware.item
            break

    if armor_cyberware:
        logging.debug(f"\tArmor cyberware found: {armor_cyberware})")
        npc.armor.add(armor_cyberware.clone(price=0, armor_locations=("Head", "Body")))
    elif not npc_template.generation_rules.allow_armor:
        logging.debug(f"\tallow_armor=False, skipped armor generation")
    else:
        data = load_data("configs/items/armor.json")

        # assume npc would select the best armor to protect himself
        all_armor: List[Item] = sorted([dataclass_wizard.fromdict(Item, x) for x in data],
                                       key=lambda x: x.price,
                                       reverse=True)
        body_armor_options = [armor for armor in all_armor if "Body" in armor.armor_locations]
        head_armor_options = [armor for armor in all_armor if "Head" in armor.armor_locations]

        total_armor_budget: int = round(npc_template.rank.items_budget[ItemType.ARMOR].generate())
        logging.debug(f"\t{total_armor_budget=}")
        logging.debug(f"\t{npc_template.role.preferred_armor_class=}")

        # try to buy a body armor with 0.8 of the total budget
        body_armor_budget: int = round(total_armor_budget * 0.8)
        logging.debug(f"\tTrying to pick a body armor with a budget of {body_armor_budget}")
        body_armor, body_armor_money_spent = pick_armor(body_armor_budget,
                                                        npc_template.role.preferred_armor_class,
                                                        body_armor_options)

        # if failed, try to buy a body armor with the whole budget
        if not body_armor:
            logging.debug(f"\tTrying to pick a body armor with a budget of {total_armor_budget}")
            body_armor, body_armor_money_spent = pick_armor(total_armor_budget,
                                                            npc_template.role.preferred_armor_class,
                                                            body_armor_options)

        if body_armor:
            logging.debug(f"\tAdded body armor: {body_armor}")
            npc.armor.add(body_armor.clone())
        else:
            logging.debug(f"\tFailed to add a body armor")

        # A single full-body item already protects both locations.
        if body_armor and "Head" in body_armor.armor_locations:
            logging.debug(f"\tBody armor also protects the head: {body_armor}")
        else:
            head_armor_budget: int = total_armor_budget - body_armor_money_spent
            logging.debug(f"\tTrying to pick a head armor with a budget of {head_armor_budget}")
            head_armor, _ = pick_armor(
                head_armor_budget, npc_template.role.preferred_armor_class, head_armor_options)

            if head_armor:
                logging.debug(f"\tAdded head armor: {head_armor}")
                npc.armor.add(head_armor.clone())
            else:
                logging.debug(f"\tFailed to add a head armor")

    # if there is a shield (in cyberware or equipment), add it as well
    shields = [item for item in npc.get_all_items() if "Shield" in item.unique_tags]
    for shield in shields:
        logging.debug(f"\tAdded shield: {shield}")
        npc.armor.add(shield)

    if len(npc.armor):
        apply_armor_penalties_once(npc)

    return npc
