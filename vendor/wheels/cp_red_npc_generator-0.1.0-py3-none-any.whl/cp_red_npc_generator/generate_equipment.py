# !/usr/bin/python
# -*- coding: utf-8 -*-

import logging
from typing import List, Optional

import dataclass_wizard

from .item import Item, ItemType
from .npc import Npc
from .npc_template import NpcTemplate
from .utils import load_data, RANDOM_GENERATING_NUM_ATTEMPTS, choose_exponential_random_element


def get_preferred_equipment_from_skills(npc: Npc, equipment: List[Item]) -> List[str]:
    skills_data = load_data("configs/skills.json")
    preferred_tags = set()
    trained_skill_names = set()

    for skill, level in npc.skills.items():
        if level <= 0:
            continue

        trained_skill_names.add(skill.name)
        skill_info = skills_data.get(skill.name, {})
        preferred_tags.update(skill_info.get("preferred_equipment_tags", []))

    return [
        item.name
        for item in equipment
        if preferred_tags.intersection(item.get_all_tags())
           or trained_skill_names.intersection(item.beautiful_names_by_skill)
    ]


def get_equipment_beautiful_name_from_skills(npc: Npc, equipment_item: Item) -> Optional[str]:
    matching_skills = sorted(
        (
            (level, skill.name, equipment_item.beautiful_names_by_skill[skill.name])
            for skill, level in npc.skills.items()
            if level > 0
               and skill.name in equipment_item.beautiful_names_by_skill
        ),
        reverse=True,
    )

    return matching_skills[0][2] if matching_skills else None


def generate_equipment(npc: Npc, npc_template: NpcTemplate) -> Npc:
    logging.debug("\nGenerating equipment...")
    if not npc_template.generation_rules.allow_equipment:
        logging.debug("allow_equipment=False, skipping...")
    else:
        data = load_data("configs/items/equipment.json")

        equipment: List[Item] = [dataclass_wizard.fromdict(Item, x) for x in data]

        equipment_by_name = {item.name: item for item in equipment}
        configured_preferred_equipment = npc_template.role.preferred_equipment
        missing_preferred_equipment = [
            name for name in configured_preferred_equipment if name not in equipment_by_name
        ]
        if missing_preferred_equipment:
            logging.warning(
                "Ignoring preferred equipment missing from the item catalog: "
                f"{missing_preferred_equipment}"
            )
        preferred_equipment: List[str] = [
            name for name in configured_preferred_equipment if name in equipment_by_name
        ]
        logging.debug(f"\t{preferred_equipment=}")

        skill_preferred_equipment = get_preferred_equipment_from_skills(npc, equipment)
        logging.debug(f"\t{skill_preferred_equipment=}")

        equipment_budget: int = round(npc_template.rank.items_budget[ItemType.EQUIPMENT].generate())
        logging.debug(f"\t{equipment_budget=}")

        max_equipment_items: int = max(round(npc_template.rank.items_num_budget[ItemType.EQUIPMENT].generate()), 0)
        logging.debug(f"\t{max_equipment_items=}")

        num_equipment_items: int = 0
        for _ in range(RANDOM_GENERATING_NUM_ATTEMPTS):
            if num_equipment_items == max_equipment_items:
                logging.debug(f"\tMax number of equipment items reached: {max_equipment_items}")
                break

            selection_pool = skill_preferred_equipment or preferred_equipment
            if not selection_pool:
                logging.debug("\tNo preferred equipment left, stopping equipment generation")
                break

            selected_equipment = choose_exponential_random_element(selection_pool)
            logging.debug(f"\tTrying to generate equipment item: {selected_equipment}")
            equipment_item: Item = equipment_by_name[selected_equipment]
            beautiful_name = get_equipment_beautiful_name_from_skills(npc, equipment_item)
            if beautiful_name is not None:
                equipment_item = equipment_item.clone(beautiful_name=beautiful_name)

            if not npc_template.generation_rules.allow_drugs and "Airhypo" in equipment_item.get_all_tags():
                logging.debug(f"\t\tallow_drugs=False, an item with \"Airhypo\" tag is useless, skipping")
                continue

            if equipment_item in npc.inventory:
                logging.debug(f"\t\tFailed, already has {equipment_item})")
                continue

            similar_inventory_item = next(
                (item for item in npc.inventory if equipment_item.contains_any_unique_tag_from(item)), None)
            if similar_inventory_item:
                logging.debug(f"\t\tFailed, similar equipment found: {similar_inventory_item}")
                if selected_equipment in skill_preferred_equipment:
                    skill_preferred_equipment.remove(selected_equipment)
                if selected_equipment in preferred_equipment:
                    preferred_equipment.remove(selected_equipment)
                continue

            similar_cyberware: Optional[Item] = None
            for cyberware in npc.cyberware:
                if equipment_item.contains_any_unique_tag_from(cyberware.item):
                    similar_cyberware = cyberware.item
                    break

            if similar_cyberware:
                logging.debug(f"\t\tFailed, similar cyberware found: {similar_cyberware})")
                continue

            if equipment_item.price > equipment_budget:
                logging.debug(
                    f"\t\tFailed, not enough money (required: {equipment_item.price}, available: {equipment_budget})")
                continue

            equipment_budget -= equipment_item.price
            npc.inventory[equipment_item] = 1
            if selected_equipment in preferred_equipment:
                preferred_equipment.remove(selected_equipment)
            if selected_equipment in skill_preferred_equipment:
                skill_preferred_equipment.remove(selected_equipment)
            logging.debug(f"\t\tSucceed, added {equipment_item}")
            logging.debug(f"\t\tMoney left: {equipment_budget}")

            num_equipment_items += 1

    logging.debug("\nGenerating money...")
    if not npc_template.generation_rules.allow_money:
        logging.debug("allow_money=False, skipping...")
    else:
        pocket_money: int = max(round(npc_template.rank.pocket_money.generate()), 0)
        if pocket_money > 0:
            eb_item = Item("Eddies", ItemType.JUNK, 1)
            npc.inventory[eb_item] = pocket_money

    return npc
